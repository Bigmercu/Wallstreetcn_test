package com.example.bigmercu.wallstreetcn_test.base;

/**
 * Created by bigmercu on 16/8/22.
 */
public interface BasePresenter {
    void start();
}
