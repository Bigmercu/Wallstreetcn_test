package com.example.bigmercu.wallstreetcn_test.ui;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.bigmercu.wallstreetcn_test.R;
import com.example.bigmercu.wallstreetcn_test.entity.Message;
import com.example.bigmercu.wallstreetcn_test.entity.Stock;

import java.util.Calendar;
import java.util.List;

/**
 * Created by bigmercu on 2016/8/22.
 * Email: bigmercu@gmail.com
 */

public class recyclerviewAdapter extends RecyclerView.Adapter<recyclerviewAdapter.MyViewHolder> {
    private Context context;
    private List<Message.MessagesBean> mMessage;
    private List<Stock> stocks;
    private List<Message.MessagesBean> mMessagesBeanList;
    private boolean isFirst = true;

    public recyclerviewAdapter(Context context, List<Message.MessagesBean> message, List<Stock> stocks) {
        this.context = context;
        this.mMessage = message;
        this.stocks = stocks;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.card, parent, false);
        return new MyViewHolder(v);
    }

    @Override
    public int getItemCount() {
        return mMessage.size();
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, int position) {
        holder.gold1.setVisibility(View.VISIBLE);
        holder.goodCount.setText(mMessage.get(position).getLikeCount());
        holder.longText.setText(mMessage.get(position).getTitle());
        holder.from.setText(mMessage.get(position).getSource());
        Calendar c = Calendar.getInstance();
        int hour = c.get(Calendar.HOUR_OF_DAY);
        int minute = c.get(Calendar.MINUTE);
        String time = hour + ":" + minute;
        holder.time.setText(time);
        if(isFirst) {
            isFirst = false;
            for(int i = 0;i< mMessage.get(position).getStocks().size();i++){
                switch (i){
                    case 0:
                        holder.mLinearLayout1.setVisibility(View.VISIBLE);
                        holder.mLinearLayout2.setVisibility(View.INVISIBLE);
                        holder.mLinearLayout3.setVisibility(View.INVISIBLE);
                        holder.gold1.setText(mMessage.get(position).getStocks().get(i).getName());
                        break;
                    case 1:
                        holder.mLinearLayout2.setVisibility(View.VISIBLE);
                        holder.gold2.setText(mMessage.get(position).getStocks().get(i).getName());
                        break;
                    case 2:
                        holder.mLinearLayout3.setVisibility(View.VISIBLE);
                        holder.gold3.setText(mMessage.get(position).getStocks().get(i).getName());
                        break;
                }
            }
        }else {
            int size = mMessage.get(position).getStocks().size();
            for(int i = 0;i< size;i++){
                switch (i){
                    case 0:
                        holder.mLinearLayout1.setVisibility(View.VISIBLE);
                        holder.mLinearLayout2.setVisibility(View.INVISIBLE);
                        holder.mLinearLayout3.setVisibility(View.INVISIBLE);
                        for(int j = 0;j < stocks.size();j++){
                            if(mMessage.get(position).getStocks().get(i).getSymbol().equals(stocks.get(j).symbol)){
                                Double temp = Double.parseDouble(String.format("%.2f",Double.parseDouble(stocks.get(j).px_change_rate)));
                                if(temp>0){
                                    holder.img1.setImageResource(R.mipmap.ic_stock_up);
                                    holder.gold1.setTextColor(context.getResources().getColor(R.color.stock_up));
                                    holder.gold1.setText(stocks.get(j).name +"+"+ temp);
                                }else {
                                    holder.img1.setImageResource(R.mipmap.ic_stock_down);
                                    holder.gold1.setTextColor(context.getResources().getColor(R.color.stock_down));
                                    holder.gold1.setText(stocks.get(j).name + temp);
                                }
                                break;
                            }
                        }
                        break;
                    case 1:
                        holder.mLinearLayout2.setVisibility(View.VISIBLE);
                        for(int j = 0;j < stocks.size();j++){
                            if(mMessage.get(position).getStocks().get(i).getSymbol().equals(stocks.get(j).symbol)){
                                Double temp = Double.parseDouble(String.format("%.2f",Double.parseDouble(stocks.get(j).px_change_rate)));
                                if(temp>0){
                                    holder.img2.setImageResource(R.mipmap.ic_stock_up);
                                    holder.gold2.setTextColor(context.getResources().getColor(R.color.stock_up));
                                    holder.gold2.setText(stocks.get(j).name +"+"+ temp);
                                }else {
                                    holder.img2.setImageResource(R.mipmap.ic_stock_down);
                                    holder.gold2.setTextColor(context.getResources().getColor(R.color.stock_down));
                                    holder.gold2.setText(stocks.get(j).name + temp);
                                }
                                break;
                            }
                        }
                        break;
                    case 2:
                        holder.mLinearLayout3.setVisibility(View.VISIBLE);
                        for(int j = 0;j < stocks.size();j++){
                            if(mMessage.get(position).getStocks().get(i).getSymbol().equals(stocks.get(j).symbol)){
                                Double temp = Double.parseDouble(String.format("%.2f",Double.parseDouble(stocks.get(j).px_change_rate)));
                                if(temp>0){
                                    holder.img3.setImageResource(R.mipmap.ic_stock_up);
                                    holder.gold3.setTextColor(context.getResources().getColor(R.color.stock_up));
                                    holder.gold3.setText(stocks.get(j).name +"+"+ temp);
                                }else {
                                    holder.img3.setImageResource(R.mipmap.ic_stock_down);
                                    holder.gold3.setTextColor(context.getResources().getColor(R.color.stock_down));
                                    holder.gold3.setText(stocks.get(j).name + temp);
                                }
                                break;
                            }
                        }
                        break;
                }
            }
        }
    }


    class MyViewHolder extends RecyclerView.ViewHolder {
        private TextView longText;
        private TextView gold1;
        private TextView gold2;
        private TextView gold3;
        private TextView time;
        private TextView from;
        private ImageView img1;
        private ImageView img2;
        private ImageView img3;
        private ImageView star1;
        private ImageView star2;
        private ImageView star3;
        private ImageButton good;
        private ImageButton share;
        private TextView goodCount;
        private String shareUrl;
        private LinearLayout mLinearLayout1;
        private LinearLayout mLinearLayout2;
        private LinearLayout mLinearLayout3;
        public MyViewHolder(View itemView) {
            super(itemView);
            longText = (TextView) itemView.findViewById(R.id.longText);
            gold1 = (TextView) itemView.findViewById(R.id.gold1);
            gold2 = (TextView) itemView.findViewById(R.id.gold2);
            gold3 = (TextView) itemView.findViewById(R.id.gold3);
            time = (TextView) itemView.findViewById(R.id.time);
            from = (TextView) itemView.findViewById(R.id.from);
            img1 = (ImageView) itemView.findViewById(R.id.img1);
            img2 = (ImageView) itemView.findViewById(R.id.img2);
            img3 = (ImageView) itemView.findViewById(R.id.img3);
            star1 = (ImageView) itemView.findViewById(R.id.star1);
            star2 = (ImageView) itemView.findViewById(R.id.star2);
            star3 = (ImageView) itemView.findViewById(R.id.star3);
            good = (ImageButton) itemView.findViewById(R.id.good);
            share = (ImageButton) itemView.findViewById(R.id.share);
            goodCount = (TextView) itemView.findViewById(R.id.likeCount);
            mLinearLayout1 = (LinearLayout) itemView.findViewById(R.id.linear1);
            mLinearLayout2 = (LinearLayout) itemView.findViewById(R.id.linear2);
            mLinearLayout3 = (LinearLayout) itemView.findViewById(R.id.linear3);
        }

    }
}