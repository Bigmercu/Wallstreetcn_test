package com.example.bigmercu.wallstreetcn_test.entity;

import com.google.gson.annotations.SerializedName;

public class RemoteBean{

    /**
     * snapshot : {"002155.SZ":["湖南黄金",-0.2900000000000009,12.79,-2.2171253822630037,"BREAK"],"002161.SZ":["远 望 谷",-0.34999999999999964,13.3,-2.5641025641025617,"BREAK"],"002234.SZ":["民和股份",-0.8599999999999994,29.89,-2.7967479674796727,"BREAK"],"002299.SZ":["圣农发展",0.10999999999999943,28.57,0.3865073787772292,"BREAK"],"002458.SZ":["益生股份",-0.45000000000000284,48.9,-0.9118541033434707,"BREAK"],"002477.SZ":["雏鹰农牧",-0.07000000000000028,5.63,-1.2280701754386014,"BREAK"],"002714.SZ":["牧原股份",-0.4499999999999993,26.42,-1.674730182359506,"BREAK"],"300498.SZ":["温氏股份",-0.39000000000000057,37.45,-1.0306553911205087,"BREAK"],"600547.SS":["山东黄金",-0.5,42.38,-1.1660447761194028,"BREAK"],"600650.SS":["锦江投资",-0.129999999999999,27.89,-0.4639543183440364,"BREAK"],"600836.SS":["界龙实业",-0.08000000000000007,10.63,-0.7469654528478065,"BREAK"],"600988.SS":["赤峰黄金",-0.16000000000000014,18.85,-0.8416622830089433,"BREAK"],"fields":["prod_name","px_change","last_px","px_change_rate","trade_status"]}
     */
    @SerializedName("data")
    private DataBean data;

    public DataBean getData() {
        return data;
    }

    public void setData(DataBean data) {
        this.data = data;
    }

    public static class DataBean {

        @SerializedName("snapshot")
        private SnapshotBean snapshot;

        @Override
        public String toString() {
            return "DataBean{" +
                    "snapshot=" + snapshot +
                    '}';
        }

        public SnapshotBean getSnapshot() {
            return snapshot;
        }


        public static class SnapshotBean {
//
//            @SerializedName("002155.SZ")
//            private List<String> SZ;
//
//            @SerializedName("600547.SS")
//            private List<String> SZ1;
//
//            @SerializedName("600988.SS")
//            private List<String> SZ2;
//
//            @SerializedName("002234.SZ")
//            private List<String> SZ3;
//
//            @SerializedName("002299.SZ")
//            private List<String> SZ4;
//
//            @SerializedName("002458.SZ")
//            private List<String> SZ5;
//
//            @SerializedName("002477.SZ")
//            private List<String> SZ6;
//
//            @SerializedName("002714.SZ")
//            private List<String> SZ7;
//
//            @SerializedName("300498.SZ")
//            private List<String> SZ8;
//
//            @SerializedName("002161.SZ")
//            private List<String> SZ9;
//
//            @SerializedName("002161.SZ")
//            private List<String> SZ10;
//
//            @SerializedName("600650.SS")
//            private List<String> SZ11;
//
//            @SerializedName("600836.SS")
//            private List<String> SZ12;
//
//            @SerializedName("300211.SZ")
//            private List<String> SZ13;
//
//            @SerializedName("300250.SZ")
//            private List<String> SZ14;
//
//            @SerializedName("300264.SZ")
//            private List<String> SZ15;
//
//            @SerializedName("000829.SZ")
//            private List<String> SZ16;
//
//            @SerializedName("600136.SS")
//            private List<String> SZ17;
//
//            @SerializedName("600158.SS")
//            private List<String> SZ18;
//
//            @SerializedName("002053.SZ")
//            private List<String> SZ19;
//
//            @SerializedName("002539.SZ")
//            private List<String> SZ20;
//
//            @SerializedName("600328.SS")
//            private List<String> SZ21;
//
//            @SerializedName("603299.SS")
//            private List<String> SZ22;
//
//            @SerializedName("002311.SZ")
//            private List<String> SZ23;
//
//            @SerializedName("002477.SZ")
//            private List<String> SZ24;
//
//            @SerializedName("000059.SZ")
//            private List<String> SZ25;
//
//            @SerializedName("002408.SZ")
//            private List<String> SZ26;
//
//            @SerializedName("000099.S")
//            private List<String> SZ27;
//
//            @SerializedName("002260.SZ")
//            private List<String> SZ28;
//
//            @SerializedName("300264.SZ")
//            private List<String> SZ29;
//
//            @SerializedName("300264.SZ")
//            private List<String> SZ30;
//
//            @SerializedName("300264.SZ")
//            private List<String> SZ29;
//
//            @SerializedName("300264.SZ")
//            private List<String> SZ30;
//
//@SerializedName("300264.SZ")
//            private List<String> SZ29;
//
//            @SerializedName("300264.SZ")
//            private List<String> SZ30;
//
//@SerializedName("300264.SZ")
//            private List<String> SZ29;
//
//            @SerializedName("300264.SZ")
//            private List<String> SZ30;
//
//@SerializedName("300264.SZ")
//            private List<String> SZ29;
//
//            @SerializedName("300264.SZ")
//            private List<String> SZ30;
//
//@SerializedName("300264.SZ")
//            private List<String> SZ29;
//
//            @SerializedName("300264.SZ")
//            private List<String> SZ30;
//
//@SerializedName("300264.SZ")
//            private List<String> SZ29;
//
//            @SerializedName("300264.SZ")
//            private List<String> SZ30;
//
//@SerializedName("300264.SZ")
//            private List<String> SZ29;
//
//            @SerializedName("300264.SZ")
//            private List<String> SZ30;
//
//
//
//
//
//
//


//
//            public List<String> getSZ() {
//                SZ.add("002477.SZ");
//                return SZ;
//            }
//
//            public void setSZ(List<String> SZ) {
//                this.SZ = SZ;
//            }
//
//            public List<String> getSZ9() {
//                return SZ9;
//            }
//
//            public void setSZ9(List<String> SZ9) {
//                this.SZ9 = SZ9;
//            }
//
//            public List<String> getSZ6() {
//                return SZ6;
//            }
//
//            public void setSZ6(List<String> SZ6) {
//                this.SZ6 = SZ6;
//            }
//
//            public List<String> getSZ5() {
//                return SZ5;
//            }
//
//            public void setSZ5(List<String> SZ5) {
//                this.SZ5 = SZ5;
//            }
//
//            public List<String> getSZ4() {
//                return SZ4;
//            }
//
//            public void setSZ4(List<String> SZ4) {
//                this.SZ4 = SZ4;
//            }
//
//            public List<String> getSZ3() {
//                return SZ3;
//            }
//
//            public void setSZ3(List<String> SZ3) {
//                this.SZ3 = SZ3;
//            }
//
//            public List<String> getSZ2() {
//                return SZ2;
//            }
//
//            public void setSZ2(List<String> SZ2) {
//                this.SZ2 = SZ2;
//            }
//
//            public List<String> getSZ1() {
//                return SZ1;
//            }
//
//            public void setSZ1(List<String> SZ1) {
//                this.SZ1 = SZ1;
//            }
//
//            public List<String> getSZ7() {
//                return SZ7;
//            }
//
//            public void setSZ7(List<String> SZ7) {
//                this.SZ7 = SZ7;
//            }
//
//            public List<String> getSZ8() {
//                return SZ8;
//            }
//
//            public void setSZ8(List<String> SZ8) {
//                this.SZ8 = SZ8;
//            }
//
//
//            @SerializedName("fields")
//            private List<String> fields;
//
//            public List<String> getFields() {
//                return fields;
//            }
//
//            public void setFields(List<String> fields) {
//                this.fields = fields;
//            }
//
// } }
        }
    }
}
