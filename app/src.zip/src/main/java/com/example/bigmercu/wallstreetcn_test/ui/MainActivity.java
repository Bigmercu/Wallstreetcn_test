package com.example.bigmercu.wallstreetcn_test.ui;

import android.content.res.AssetManager;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import com.example.bigmercu.wallstreetcn_test.R;
import com.example.bigmercu.wallstreetcn_test.contract.getDataContract;
import com.example.bigmercu.wallstreetcn_test.entity.Message;
import com.example.bigmercu.wallstreetcn_test.entity.Stock;
import com.example.bigmercu.wallstreetcn_test.model.getDataModelImpl;
import com.example.bigmercu.wallstreetcn_test.presenter.getDataPresenterImpl;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import static com.example.bigmercu.wallstreetcn_test.R.id.recyclerView;

public class MainActivity extends AppCompatActivity implements getDataContract.View {

    private static final String TAG = MainActivity.class.getSimpleName();
    private static final int STATUS_FIRST = 1;
    private static final int STATUS_OTHER = 2;
    private getDataContract.Presenter mGetDataPresenter;
    private RecyclerView mRecyclerView ;
    private List<Message.MessagesBean> mMessage = new ArrayList<>();
    private  List<Stock> stocks = new ArrayList<>();
    private int status = STATUS_FIRST;
    private recyclerviewAdapter recyclerviewAdapter;
    private ArrayList<String> symbolCodeList = new ArrayList<>();
    private ArrayList<String> filedList = new ArrayList<>();
    private int count = 0;


    Handler mHandler = new Handler(){
        @Override
        public void handleMessage(android.os.Message msg) {
            super.handleMessage(msg);
            switch (msg.what){
                case 1:
                    recyclerviewAdapter.notifyDataSetChanged();
                    break;
            }
        }
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        new getDataPresenterImpl(this);
        mRecyclerView = (RecyclerView) findViewById(recyclerView);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext());
        mRecyclerView.setLayoutManager(linearLayoutManager);
        recyclerviewAdapter = new recyclerviewAdapter(getApplicationContext(),mMessage,stocks);
        mRecyclerView.setAdapter(recyclerviewAdapter);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        initData();
        readCacheFromAssets();
    }

    private void readCacheFromAssets(){
        AssetManager assetManager = getAssets();
        mGetDataPresenter.getLocalData(assetManager);
        status = STATUS_OTHER;
    }

    private void initData(){
        geiSymbolList();
        filedList.add("prod_name");
        filedList.add("px_change");
        filedList.add("last_px");
        filedList.add("px_change_rate");
        filedList.add("trade_status");
    }

    private   List<String>  geiSymbolList(){
        JSONArray jsonObj = null;
        try {
            String json = getDataModelImpl.getJsonData(getApplicationContext().getAssets());
            jsonObj = new JSONObject(json).getJSONArray("Messages");
            for(int i =0;i < jsonObj.length();i++){
                JSONArray jsonArray = new JSONObject(String.valueOf(jsonObj.get(i))).getJSONArray("Stocks");
                for(int j = 0;j < jsonArray.length();j++) {
                    String Symbol = new JSONObject(String.valueOf(jsonArray.get(j))).getString("Symbol");
                    if(Symbol != "" && Symbol != null){
                        symbolCodeList.add(Symbol);
                    }
                }

            }


        } catch (JSONException e) {
            e.printStackTrace();
        }
        return symbolCodeList;
    }

    @Override
    public void setData(Message message) {
        mMessage.clear();
        mMessage.addAll(message.getMessages());
        recyclerviewAdapter.notifyDataSetChanged();
        mGetDataPresenter.getRemoteData(symbolCodeList,filedList);
    }

    @Override
    public void setData(List<Stock> stock) {
        stocks.clear();
        stocks.addAll(stock);
        recyclerviewAdapter.notifyDataSetChanged();
        count++;
        Snackbar.make(mRecyclerView,"第" + count + "次更新",Snackbar.LENGTH_SHORT).show();
    }

    @Override
    public void onFiled(String info) {
        Toast.makeText(getApplicationContext(),info,Toast.LENGTH_SHORT).show();
    }

    @Override
    public void setPresenter(getDataContract.Presenter presenter) {
        this.mGetDataPresenter = presenter;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mGetDataPresenter.onCancle();
    }
}
