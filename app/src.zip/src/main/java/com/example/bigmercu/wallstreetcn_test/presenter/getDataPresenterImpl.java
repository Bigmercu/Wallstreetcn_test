package com.example.bigmercu.wallstreetcn_test.presenter;

import android.content.res.AssetManager;
import android.util.Log;

import com.example.bigmercu.wallstreetcn_test.contract.getDataContract;
import com.example.bigmercu.wallstreetcn_test.entity.Message;
import com.example.bigmercu.wallstreetcn_test.entity.Stock;
import com.example.bigmercu.wallstreetcn_test.model.getDataModelImpl;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by bigmercu on 2016/8/22.
 * Email: bigmercu@gmail.com
 */

public class getDataPresenterImpl implements getDataContract.Presenter,getDataModelImpl.onGetDataListener{
    private getDataContract.View mView;
    private getDataModelImpl mGetDataModel;
    private static final String TAG = getDataPresenterImpl.class.getSimpleName();

    public getDataPresenterImpl(getDataContract.View view){
        this.mView = view;
        mGetDataModel = getDataModelImpl.getInstance();
        view.setPresenter(this);
    }

    @Override
    public void getRemoteData( ArrayList<String> symbolCodeList,  ArrayList<String> filedList) {
        mGetDataModel.getRemoteData(symbolCodeList,filedList,getDataPresenterImpl.this);
    }

    @Override
    public void getLocalData(AssetManager asserter) {
        mGetDataModel.getLocalData(asserter,this);
    }

    @Override
    public void onCancle() {
        mGetDataModel.onCancle();
    }

    @Override
    public void start() {
        Log.d(TAG,"start");
    }

    @Override
    public void onSuccess(Message message) {
        mView.setData(message);
    }

    @Override
    public void onSuccess( List<Stock> stock) {
        mView.setData(stock);
    }

    @Override
    public void onFiled(String info) {
        mView.onFiled(info);
    }
}
