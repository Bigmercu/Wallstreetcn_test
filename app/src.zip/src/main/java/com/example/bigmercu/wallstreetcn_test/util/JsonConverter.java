package com.example.bigmercu.wallstreetcn_test.util;

import android.util.Log;

import com.google.gson.Gson;

/**
 * Created by bigmercu on 2016/8/22.
 * Email: bigmercu@gmail.com
 */

public class JsonConverter<T> {

    @SuppressWarnings("unchecked")
    public  T getParsedObj(String jsonData) throws Exception{
        Gson gson = new Gson();
        try {
            return (T) gson.fromJson(jsonData, this.getClass());
        } catch (Exception e) {
            Log.d("JsonConverter","error");
        }
        return null;
    }
}